Page({
  data: {
    dishes: [
      {
        "id": "11",
        "name": "牛肉面/粉",
        "image": "https://tse3-mm.cn.bing.net/th/id/OIP-C.VcTct0pF8-IVyciAOyB0EgHaE8?w=284&h=189&c=7&r=0&o=5&dpr=1.3&pid=1.7"
      },
      {
        "id": "12",
        "name": "韩式拌饭",
        "image": "https://img2.baidu.com/it/u=78515055,2305939745&fm=253&fmt=auto&app=120&f=JPEG?w=1280&h=800"
      },
      {
        "id": "13",
        "name": "港式滑蛋饭",
        "image": "https://img0.baidu.com/it/u=383665668,2693881757&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500"
      },
      {
        "id": "14",
        "name": "肥牛面/粉",
        "image": "https://img2.baidu.com/it/u=2952767361,1745663000&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750"
      },
      {
        "id": "15",
        "name": "巴西烤肉拌面/粉",
        "image": "https://img2.baidu.com/it/u=3802523785,3032380104&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=333"
      },
      {
        "id": "16",
        "name": "泰式烤鸡拌面/粉",
        "image": "https://img1.baidu.com/it/u=3472178342,4280205170&fm=253&fmt=auto&app=120&f=JPEG?w=1067&h=800"
      },
      {
        "id": "17",
        "name": "南昌拌粉",
        "image": "https://img1.baidu.com/it/u=3626603304,4194052936&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750"
      },
      {
        id: "18",
        name: "茶油小炒鸡汤面/粉",
        image: "https://img1.baidu.com/it/u=1349052244,157129944&fm=253&fmt=auto&app=138&f=JPEG?w=700&h=445"
      },
      {
        id: "19",
        name: "柳州螺蛳粉",
        image: "https://img1.baidu.com/it/u=2082581552,3188870799&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=749"
      },
      {
        id: "20",
        name: "肉饼汤",
        image: "https://img2.baidu.com/it/u=2111640943,638831079&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750"
      }
      // ... 添加更多菜品
    ]
  }
})