// pages/slimming/slimming.js
Page({
  data: {
    dishes: [
      {
        id: '1',
        name: '五谷豆浆',
        image: 'https://img0.baidu.com/it/u=2633501200,1561793416&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=667'
      },
      {
        id: '2',
        name: '八宝粥',
        image: 'https://img1.baidu.com/it/u=1103887659,3808474786&fm=253&fmt=auto&app=120&f=JPEG?w=889&h=500'
      },
      {
        id:'3',
        name:'牛奶燕麦粥',
        image:'https://img1.baidu.com/it/u=901446516,4055118578&fm=253&fmt=auto&app=138&f=JPEG?w=428&h=285'
      },
      {
        id:'4',
        name:'皮蛋瘦肉粥',
        image:'https://img1.baidu.com/it/u=708928081,577622850&fm=253&fmt=auto&app=120&f=JPEG?w=1000&h=638'
      },
      {
        id:'5',
        name:'青花椒烤鱼',
        image:'https://img0.baidu.com/it/u=589159121,1797774050&fm=253&fmt=auto&app=138&f=JPEG?w=752&h=500'
      },
      {
        id:'6',
        name:'牛肉拉面',
        image:'https://img0.baidu.com/it/u=1885582174,1350055436&fm=253&fmt=auto&app=138&f=JPEG?w=650&h=433'
      },
      {
        id:'7',
        name:'酸奶包',
        image:'http://t15.baidu.com/it/u=3321049252,2067336465&fm=224&app=112&f=JPEG?w=500&h=500'
      },
      {
        id:'8',
        name:'素青菜面/粉',
        image:'https://img1.baidu.com/it/u=3824556246,302212101&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500'
      },
      {
        id:'9',
        name:'蒜薹小油菜',
        image:'https://img0.baidu.com/it/u=1840305542,4149040941&fm=253&fmt=auto&app=138&f=JPEG?w=600&h=400'
      },
      {
        id:'10',
        name:'椰奶包',
        image:'https://img2.baidu.com/it/u=1046537110,89093564&fm=253&fmt=auto&app=120&f=JPEG?w=500&h=333'
      }
      // ... 添加更多菜品
    ]
  }
})