// pages/balance/balance.js
Page({
  data: {
    dishes: [
      {
        "id": "21",
        "name": "套餐饭 (1主荤+2素菜+米饭)",
        "image": "https://img1.baidu.com/it/u=2777088389,4119620024&fm=253&fmt=auto&app=138&f=JPEG?w=640&h=427"
      },
      {
        "id": "22",
        "name": "金日升烤盘饭",
        "image": "https://img1.baidu.com/it/u=1542711507,3299051246&fm=253&fmt=auto&app=138&f=JPEG?w=667&h=500"
      },
      {
        "id": "23",
        "name": "黄焖鸡米饭",
        "image": "https://img2.baidu.com/it/u=1377292106,2225716851&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500"
      },
      {
        "id": "24",
        "name": "牛肉拉面",
        "image": "https://img2.baidu.com/it/u=3844657804,1681123779&fm=253&fmt=auto&app=138&f=JPEG?w=685&h=500"
      },
      {
        "id": "25",
        "name": "金汤鱼",
        "image": "https://img2.baidu.com/it/u=334870518,3984115530&fm=253&fmt=auto&app=138&f=JPEG?w=752&h=500"
      },
      {
        "id": "26",
        "name": "老坛酸菜鱼",
        "image": "https://img0.baidu.com/it/u=1374225101,725279434&fm=253&fmt=auto&app=138&f=JPEG?w=900&h=500"
      },
      {
        "id": "27",
        "name": "豆角炒回锅肉",
        "image": "https://img1.baidu.com/it/u=1416718540,3448873563&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500"
      },
      {
        "id": "28",
        "name": "鱼香肉丝",
        "image": "https://img1.baidu.com/it/u=3565973872,3801501263&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500"
      },
      {
        "id": "29",
        "name": "包菜粉丝",
        "image": "https://img1.baidu.com/it/u=87590046,2151010140&fm=253&fmt=auto&app=120&f=JPEG?w=1142&h=731"
      },
      {
        "id": "30",
        "name": "素青菜面/粉",
        "image": "https://img2.baidu.com/it/u=3833630309,3534552292&fm=253&fmt=auto&app=138&f=JPEG?w=667&h=500"
      }
      
    ]
  }
})