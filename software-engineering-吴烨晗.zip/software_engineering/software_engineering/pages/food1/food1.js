Page({
  data: {
    dish: {}
  },
  onLoad: function (options) {
    // 假设你有一个方法来获取菜品详情
    this.getDishDetails(options.id);
  },
  getDishDetails: function (id) {
    // 这里应该是一个 API 请求来获取数据，这里我们使用模拟数据
    const details = {
      '1': {
        name: '五谷豆浆',
        image: 'https://img0.baidu.com/it/u=2633501200,1561793416&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=667',
        energy: 150,
        fat: 4,
        protein: 6,
        carbs: 20
        // ...其他信息
      },
      '2': {
        name: '八宝粥',
        image: 'https://img1.baidu.com/it/u=1103887659,3808474786&fm=253&fmt=auto&app=120&f=JPEG?w=889&h=500',
        energy: 150,
        fat: 15,
        protein:15 ,
        carbs:15 
       
        // ...其他信息
      },
      '3': {
        name: '牛奶燕麦粥',
        image: 'https://img1.baidu.com/it/u=901446516,4055118578&fm=253&fmt=auto&app=138&f=JPEG?w=428&h=285',
        energy:180 ,
        fat: 15,
        protein:25 ,
        carbs:20 
      
        // ...其他信息
      },
      '4': {
        name: '皮蛋瘦肉粥',
        image: 'https://img1.baidu.com/it/u=708928081,577622850&fm=253&fmt=auto&app=120&f=JPEG?w=1000&h=638',
        energy:180 ,
        fat: 15,
        protein:40 ,
        carbs:16 
     
        // ...其他信息
      },
      '5': {
        name: '青花椒烤鱼',
        image: 'https://img0.baidu.com/it/u=589159121,1797774050&fm=253&fmt=auto&app=138&f=JPEG?w=752&h=500',
        energy:350 ,
        fat: 15,
        protein:25 ,
        carbs:80 
        
        // ...其他信息
      },
      '6': {
        name: '牛肉拉面',
        image: 'https://img0.baidu.com/it/u=1885582174,1350055436&fm=253&fmt=auto&app=138&f=JPEG?w=650&h=433',
        energy:550 ,
        fat: 15,
        protein:25 ,
        carbs:80 
        // ...其他信息
      },
      '7': {
        name: '酸奶包',
        image: 'http://t15.baidu.com/it/u=3321049252,2067336465&fm=224&app=112&f=JPEG?w=500&h=500',
        energy:200 ,
        fat: 4,
        protein:5,
        carbs:30 
        // ...其他信息
      },
      '8': {
        name: '素青菜面/粉',
        image: 'https://img1.baidu.com/it/u=3824556246,302212101&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500',
        energy:350 ,
        fat: 1,
        protein:8,
        carbs:70 
        // ...其他信息
      },
      '9': {
        name: '蒜薹小油菜',
        image: 'https://img0.baidu.com/it/u=1840305542,4149040941&fm=253&fmt=auto&app=138&f=JPEG?w=600&h=400',
        energy:120 ,
        fat: 6,
        protein:3,
        carbs:10 
        // ...其他信息
      },
      '10': {
        name: '椰奶包',
        image: 'https://img2.baidu.com/it/u=1046537110,89093564&fm=253&fmt=auto&app=120&f=JPEG?w=500&h=333',
        energy:220 ,
        fat: 8,
        protein:4,
        carbs:30 
        // ...其他信息
      },
      '11': {
        name: '牛肉面/粉',
        image: 'https://tse3-mm.cn.bing.net/th/id/OIP-C.VcTct0pF8-IVyciAOyB0EgHaE8?w=284&h=189&c=7&r=0&o=5&dpr=1.3&pid=1.7',
        energy: 500,
        fat: 16,
        protein: 30,
        carbs: 60
        // ...其他信息
      },
      '12': {
        name: '韩式拌饭',
        image: 'https://img2.baidu.com/it/u=78515055,2305939745&fm=253&fmt=auto&app=120&f=JPEG?w=1280&h=800',
        energy: 450,
        fat: 10,
        protein: 20,
        carbs: 65
        // ...其他信息
      },
      '13': {
        name: '港式滑蛋饭',
        image: 'https://img0.baidu.com/it/u=383665668,2693881757&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500',
        energy: 400,
        fat: 15,
        protein: 18,
        carbs: 50
        // ...其他信息
      },
      '14': {
        name: '肥牛面/粉',
        image: 'https://img2.baidu.com/it/u=2952767361,1745663000&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750',
        energy: 450,
        fat: 12,
        protein: 25,
        carbs: 65
        // ...其他信息
      },
      '15': {
        name: '巴西烤肉拌面/粉',
        image: 'https://img2.baidu.com/it/u=3802523785,3032380104&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=333',
        energy: 600,
        fat: 22,
        protein: 35,
        carbs: 60
        // ...其他信息
      },
      '16': {
        name: '泰式烤鸡拌面/粉',
        image: 'https://img1.baidu.com/it/u=3472178342,4280205170&fm=253&fmt=auto&app=120&f=JPEG?w=1067&h=800',
        energy: 450,
        fat: 12,
        protein: 28,
        carbs: 55
        // ...其他信息
      },
      '17': {
        name: '南昌拌粉',
        image: 'https://img1.baidu.com/it/u=3626603304,4194052936&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750',
        energy: 300,
        fat: 4,
        protein: 8,
        carbs: 55
        // ...其他信息
      },
      '18': {
        name: '茶油小炒鸡汤面/粉',
        image: 'https://img1.baidu.com/it/u=1349052244,157129944&fm=253&fmt=auto&app=138&f=JPEG?w=700&h=445',
        energy: 380,
        fat: 10,
        protein: 23,
        carbs: 55
        // ...其他信息
      },
      '19': {
        name: '柳州螺蛳粉',
        image: 'https://img1.baidu.com/it/u=2082581552,3188870799&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=749',
        energy: 320,
        fat: 7,
        protein: 12,
        carbs: 50
        // ...其他信息
      },
      '20': {
        name: '肉饼汤',
        image: 'https://img2.baidu.com/it/u=2111640943,638831079&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750',
        energy: 250,
        fat: 15,
        protein: 20,
        carbs: 10
        // ...其他信息
      },
      "21": {
        "name": "套餐饭 (1主荤+2素菜+米饭)",
        "image": "https://img1.baidu.com/it/u=2777088389,4119620024&fm=253&fmt=auto&app=138&f=JPEG?w=640&h=427",
        "energy": 550,
        "fat": 20,
        "protein": 40,
        "carbs": 70
      },
      "22": {
        "name": "金日升烤盘饭",
        "image": "https://img1.baidu.com/it/u=1542711507,3299051246&fm=253&fmt=auto&app=138&f=JPEG?w=667&h=500",
        "energy": 600,
        "fat": 25,
        "protein": 30,
        "carbs": 80
      },
      "23": {
        "name": "黄焖鸡米饭",
        "image": "https://img2.baidu.com/it/u=1377292106,2225716851&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500",
        "energy": 500,
        "fat": 15,
        "protein": 35,
        "carbs": 65
      },
      "24": {
        "name": "牛肉拉面",
        "image": "https://img2.baidu.com/it/u=3844657804,1681123779&fm=253&fmt=auto&app=138&f=JPEG?w=685&h=500",
        "energy": 480,
        "fat": 18,
        "protein": 28,
        "carbs": 60
      },
      "25": {
        "name": "金汤鱼",
        "image": "https://img2.baidu.com/it/u=334870518,3984115530&fm=253&fmt=auto&app=138&f=JPEG?w=752&h=500",
        "energy": 420,
        "fat": 12,
        "protein": 32,
        "carbs": 50
      },
      "26": {
        "name": "老坛酸菜鱼",
        "image": "https://img0.baidu.com/it/u=1374225101,725279434&fm=253&fmt=auto&app=138&f=JPEG?w=900&h=500",
        "energy": 400,
        "fat": 9,
        "protein": 38,
        "carbs": 40
      },
      "27": {
        "name": "豆角炒回锅肉",
        "image": "https://img1.baidu.com/it/u=1416718540,3448873563&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500",
        "energy": 530,
        "fat": 22,
        "protein": 25,
        "carbs": 60
      },
      "28": {
        "name": "鱼香肉丝",
        "image": "https://img1.baidu.com/it/u=3565973872,3801501263&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500",
        "energy": 350,
        "fat": 10,
        "protein": 20,
        "carbs": 45
      },
      "29": {
        "name": "包菜粉丝",
        "image": "https://img1.baidu.com/it/u=87590046,2151010140&fm=253&fmt=auto&app=120&f=JPEG?w=1142&h=731",
        "energy": 320,
        "fat": 5,
        "protein": 12,
        "carbs": 60
      },
      "30": {
        "name": "素青菜面/粉",
        "image": "https://img2.baidu.com/it/u=3833630309,3534552292&fm=253&fmt=auto&app=138&f=JPEG?w=667&h=500",
        "energy": 380,
        "fat": 8,
        "protein": 15,
        "carbs": 55
      },
      "31": {
        "name": "套餐饭 (1主荤+2素菜+米饭)",
        "image": "https://img0.baidu.com/it/u=3165288271,525251595&fm=253&fmt=auto&app=138&f=JPG?w=500&h=293",
        "energy": 550, 
        "fat": 20, 
        "protein": 40,
        "carbs": 70
      },
      "32": {
        "name": "F+ 牛肉饭",
        "image": "https://img0.baidu.com/it/u=1518628875,526224061&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=375",
        "energy": 600,
        "fat": 22,
        "protein": 45,
        "carbs": 50
      },
      "33": {
        "name": "港式滑蛋饭",
        "image": "https://img2.baidu.com/it/u=2128162715,2211710978&fm=253&fmt=auto&app=138&f=JPEG?w=780&h=439",
        "energy": 400,
        "fat": 18,
        "protein": 20,
        "carbs": 45
      },
      "34": {
        "name": "韩式拌饭",
        "image": "https://img2.baidu.com/it/u=1185261366,1278739783&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=666",
        "energy": 500,
        "fat": 15,
        "protein": 30,
        "carbs": 60
      },
      "35": {
        "name": "牛肉拉面",
        "image": "https://img1.baidu.com/it/u=1511339654,4046395604&fm=253&fmt=auto&app=138&f=JPEG?w=667&h=500",
        "energy": 480,
        "fat": 18,
        "protein": 28,
        "carbs": 60
      },
      "36": {
        "name": "巴西烤肉拌面/粉",
        "image": "https://img0.baidu.com/it/u=994184243,2621088182&fm=253&fmt=auto&app=138&f=JPEG?w=640&h=388",
        "energy": 580,
        "fat": 25,
        "protein": 35,
        "carbs": 55
      },
      "37": {
        "name": "泰式烤鸡拌面/粉",
        "image": "http://t15.baidu.com/it/u=1309715242,265545911&fm=224&app=112&f=JPEG?w=500&h=500",
        "energy": 550,
        "fat": 20,
        "protein": 42,
        "carbs": 53
      },
      "38": {
        "name": "老坛酸菜鱼",
        "image": "https://img0.baidu.com/it/u=2288773118,3931796096&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750",
        "energy": 400,
        "fat": 9,
        "protein": 38,
        "carbs": 40
      },
      "39": {
        "name": "哎呦喂 麻辣烫/麻辣拌",
        "image": "https://img2.baidu.com/it/u=996674729,76073224&fm=253&fmt=auto&app=138&f=JPEG?w=727&h=500",
        "energy": 480,
        "fat": 16,
        "protein": 30,
        "carbs": 58
      },
      "40": {
        "name": "牛/羊肉水饺",
        "image": "https://img1.baidu.com/it/u=665639476,2567701683&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500",
        "energy": 420,
        "fat": 10,
        "protein": 26,
        "carbs": 50
      }
        
      
      // ...更多菜品信息
    };
    
    if (details[id]) {
      this.setData({
        dish: details[id]
      });
    } else {
      // 处理错误或者说未找到菜品情况
    }
  }
})
