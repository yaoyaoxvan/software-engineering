// pages/eat_well/eat_well.js
Page({
  data: {
    dishes: [
      {
        "id": "31",
        "name": "套餐饭 (1主荤+2素菜+米饭)",
        "image": "https://img0.baidu.com/it/u=3165288271,525251595&fm=253&fmt=auto&app=138&f=JPG?w=500&h=293"
      },
      {
        "id": "32",
        "name": "F+ 牛肉饭",
        "image": "https://img0.baidu.com/it/u=1518628875,526224061&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=375"
      },
      {
        "id": "33",
        "name": "港式滑蛋饭",
        "image": "https://img2.baidu.com/it/u=2128162715,2211710978&fm=253&fmt=auto&app=138&f=JPEG?w=780&h=439"
      },
      {
        "id": "34",
        "name": "韩式拌饭",
        "image": "https://img2.baidu.com/it/u=1185261366,1278739783&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=666"
      },
      {
        "id": "35",
        "name": "牛肉拉面",
        "image": "https://img1.baidu.com/it/u=1511339654,4046395604&fm=253&fmt=auto&app=138&f=JPEG?w=667&h=500"
      },
      {
        "id": "36",
        "name": "巴西烤肉拌面/粉",
        "image": "https://img0.baidu.com/it/u=994184243,2621088182&fm=253&fmt=auto&app=138&f=JPEG?w=640&h=388"
      },
      {
        "id": "37",
        "name": "泰式烤鸡拌面/粉",
        "image": "http://t15.baidu.com/it/u=1309715242,265545911&fm=224&app=112&f=JPEG?w=500&h=500"
      },
      {
        "id": "38",
        "name": "老坛酸菜鱼",
        "image": "https://img0.baidu.com/it/u=2288773118,3931796096&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=750"
      },
      {
        "id": "39",
        "name": "哎呦喂 麻辣烫/麻辣拌",
        "image": "https://img2.baidu.com/it/u=996674729,76073224&fm=253&fmt=auto&app=138&f=JPEG?w=727&h=500"
      },
      {
        "id": "40",
        "name": "牛/羊肉水饺",
        "image": "https://img1.baidu.com/it/u=665639476,2567701683&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500"
      }
      
    ]
  }
})