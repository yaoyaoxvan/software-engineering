// pages/ear2/ear2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  click1 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/guanbing/guanbing'
    })
  },
  click2 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/tesetaocan/tesetaocan'
    })
  },
  click3 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/guokui/guokui'
    })
  },
  click4 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/caijianbing/caijianbing'
    })
  },
  click5 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/yubao/yubao'
    })
  },
  click6 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/hanbao/hanbao'
    })
  },
  click7 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/laofan/laofan'
    })
  },
  click8 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/baozi/baozi'
    })
  },
  click9 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/banmian/banmian'
    })
  },
  click10 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/pafan/pafan'
    })
  },
  click11 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/chuantianjiao/chuantianjiao'
    })
  },
  click12 :function(){
    wx.navigateTo({
      url: '/introduce/hear2/lanzhiwei/lanzhiwei'
    })
  }
})