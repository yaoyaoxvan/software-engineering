// pages/ear1/ear1.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  click11 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/zixuan/zixuan'
    })
  },
  click12 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/jiachangcai/jiachangcai'
    })
  },
  click13 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/yiwan/yiwan'
    })
  },
  click14 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/limiji/limiji'
    })
  },
  click15 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/feizhi/feizhi'
    })
  },
  click16 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/tangfen/tangfen'
    })
  },
  click17 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/diguoji/diguoji'
    })
  },
  click18 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/luroufan/luroufan'
    })
  },
  click19 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/shuijiao/shuijiao'
    })
  },
  click110 :function(){
    wx.navigateTo({
      url: '/introduce/hear1/koushuiji/koushuiji'
    })
  },
});